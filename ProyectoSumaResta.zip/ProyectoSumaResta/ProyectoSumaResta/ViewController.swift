//
//  ViewController.swift
//  ProyectoSumaResta
//
//  Created by Jesus Menendez on 4/11/18.
//  Copyright © 2018 Jesus Menendez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var valor1: UITextField!
    
    @IBOutlet weak var valor2: UITextField!
    
    @IBOutlet weak var resultado: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
            }
    
    @IBAction func Resta(_ sender: UIButton) {
        /*let Valor1 = Float(valor1.text!)
        let Valor2 = Float(valor2.text!)
        let resta = Valor1! - Valor2!*/
        
        let resta = Float(valor1.text!)! -  Float(valor2.text!)! // verificar con el codigo anterior el checar que sean validos para ""
        resultado.text = "El resultado es: \(resta)"
    }
    @IBAction func Suma(_ sender: UIButton) {
        let Valor1 = Float(valor1.text!)
        let Valor2 = Float(valor2.text!)
        let suma = Valor1! + Valor2!
        resultado.text = "El resultado es: \(suma) "
    }
}

