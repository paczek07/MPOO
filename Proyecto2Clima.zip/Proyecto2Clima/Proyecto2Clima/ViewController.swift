//
//  ViewController.swift
//  Proyecto2Clima
//
//  Created by Jesus Menendez on 4/11/18.
//  Copyright © 2018 Jesus Menendez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    //var Array = [UIImage]()
    
    
    @IBOutlet weak var climaLabel: UILabel!
    @IBOutlet weak var temperaturaLabel: UILabel!
    @IBOutlet weak var sliderOn: UISlider!
    @IBOutlet weak var imageViewer: UIImageView!
    
    // mejorar el codigo para evitar el uso de if...
    // de ser posible aumentar de 5 en 5 
    
    @IBAction func slider(_ sender: UISlider) {
        
        var value = Int(sender.value) // This saves the value of sender to a variable
        print(sliderOn.value)
        temperaturaLabel.text = "La temperatura es \(Int(sliderOn.value * 100)) ºC " // describe la temperatura
        
        if sliderOn.value > 0.2 && sliderOn.value <= 0.5 {
            climaLabel.text = "Soleado"
            imageViewer.image = #imageLiteral(resourceName: "soleado")
        } else if sliderOn.value > 0.0 && sliderOn.value < 0.2 {
            climaLabel.text = "Nublado"
            imageViewer.image = #imageLiteral(resourceName: "nublado")
        }else{
            climaLabel.text = "Frio"
            imageViewer.image = #imageLiteral(resourceName: "frio")
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        temperaturaLabel.text = String(sliderOn.value)
    }


}

